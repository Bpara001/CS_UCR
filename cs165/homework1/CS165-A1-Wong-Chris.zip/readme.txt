
*************GENERAL*************

-Please note, I did not soley depend on my program to solve the problems.
I merely used it as a tool to help me solve it; "You will be graded on the correctness of your results."Thus, one cannont simply input the problem into my program, thenoutput the solution. Instead, a few minor steps are required (and the approriate work/ documentation is included).

-Portions of my code may be 'commented' out, b/c that portion may be an
independent step to solving the porblem(s)

-The appropriate solution(the decoded plaintext) for each problem are in its corresponding problem folder directory in the textfile, "output.txt"

-Program(s) are written in C++ with the filename "main.cpp"



***************FOR PROBLEM #1**************************

decoded.txt was generated from PHASE 2 (of main.cpp), and used in PHASE 3

"frequency analysis.xlsx", a excel spreadsheet made by me to help me solve the letter subsition

wolfram was used to find factors of 1 specific number


***************FOR PROBLEM #2*************************

To find LCG values (n,a,b) I used an algorithum from online,
(not the method described in class)
http://sandeepmore.com/blog/tag/breaking-lcg/

wolframalpha was used to find gcd of 1 specific number, and
a systems of linear equations.

